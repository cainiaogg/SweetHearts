<template lang="html">
    <div class="page">
        <header>
            <span @click="goAdd()">发表</span>
            <span class="friendship">好友圈</span>
            <span></span>
        </header>
        <mt-loadmore :top-method="loadTop"  ref="loadmore">
            <ul class="page"
                v-infinite-scroll="loadBottom"
                infinite-scroll-disabled="loading"
                infinite-scroll-distance="10">
                <li class="circle-item" v-for="item in friendCircleList">
                    <div class="header">
                        <div class="headerImg">
                            <img :src="item.headerUrl" alt="头像">
                        </div>
                        <div class="intro">
                            <span style="display:inline-block;">{{item.UserName}}</span>
                            <i class="tags" v-if="item.ishoney==1"></i>
                            <span class="time">{{item.TimeStamp}}</span>
                        </div>
                    </div>
                    <div class="content">
                        {{item.Content}}
                    </div>
                    <ul class="picList">
                        <li v-for="urlItem in item.picList">
                            <img :src="urlItem" alt="图片">
                        </li>
                    </ul>
                </li>
            </ul>
        </mt-loadmore>

    </div>
</template>

<script>
export default {
    created (){
        const reg = /username=.*$/g;
        console.log(location.href.match(reg));
        let username = location.href.match(reg)[0].split('=')[1];
        this.username =username;
        this.initData(1);
    },
    methods: {
        goAdd (){
            this.$router.push('/add?username='+this.username);
        },
        initData (mypage){
            let username = this.username;
            let page = mypage?mypage:this.page;
            let url = 'http://192.168.253.18:8080/circle/get_friend_circle?username=' + username + '&page=' + page;
            var self = this;

            if (page == 1) {
                this.friendCircleList = []
            }
            this.$http.get(url)
            .then(function(res){
                console.log(res.body);
                res.body.forEach(function(item, index){
                    let obj = {};
                    obj.Content = item.Content;
                    obj.picList = item.ImagePath;
                    obj.UserName = item.UserName;
                    obj.TimeStamp = (new Date(item.TimeStamp).getMonth()+1) + '月' + (new Date(item.TimeStamp).getDate()) + '日' + (new Date(item.TimeStamp).getHours())+":"+(new Date(item.TimeStamp).getMinutes() <10 ? '0' + new Date(item.TimeStamp).getMinutes() : new Date(item.TimeStamp).getMinutes());
                    obj.headerUrl = item.HeadImage ? item.HeadImage : 'https://o5wwk8baw.qnssl.com/a42bdcc1178e62b4694c830f028db5c0/avatar';
                    obj.ishoney = item.IsHoney;
                    self.friendCircleList.push(obj);
                });
                self.loading = false;
            })
        },
        loadTop (){
            this.$refs.loadmore.onTopLoaded();
            this.initData(1);
        },
        loadBottom (){
            this.loading = true;
            let index = this.page++;
            let self = this;
            this.initData(index);
        }
    },
    data() {
        return {
            friendCircleList: [],
            username: 'admin',
            page: 1,
            allLoaded: false
        }
    }
}
</script>

<style scoped>
    header {
        height: 48px;
        width: 100%;
        background-color: #12b7f5;
        box-sizing: border-box;
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 6px;
        padding-left: 16px;
    }
    header span {
        display: block;
        color: #fff;
        font-size: 16px;
        font-weight: 500;
        width: 80px;
    }
    .friendship {
        text-align: center;
    }
    .circle-item {
        background-color: #fff;
        margin-bottom: 12px;
        border-bottom: 1px dashed #ccc;
        border-top: 1px dashed #ccc;
    }
    .headerImg {
        flex-basis: 50px;
        padding-right: 10px;
    }
    .intro {
        flex: 1;
        color: #000;
    }
    .intro .time {
        color:#ccc;
    }
    .headerImg img{
        width: 40px;
        height: 40px;
        border-radius: 50%;
        box-shadow: 1px 1px 1px 1px #fff;
    }
    .header {
        height: 48px;
        width: 100%;
        background-color: #fff;
        box-sizing: border-box;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding-left: 16px;
        padding-right: 16px;
    }
    .header span {
        display: block;
        color: #000;
        font-size: 16px;
        font-weight: 500;
    }
    .content {
        background-color: #fff;
        padding: 16px;
        font-size: 14px;
    }
    .picList {
        max-width: 100%;
        padding: 0 16px;
        display: flex;
        flex-wrap: wrap;
        padding-bottom: 10px;
    }
    .picList li {
        min-width: 33.33%;
        width: 33.33%;
        max-width: 100%;
        max-height: 120px;
        padding-bottom: 2px;
        padding-left: 2px;
        padding-top: 2px;
        overflow: hidden;
    }
    .picList img {
        flex:0;
        display: block;
        width: 100%;
        height: 100%;
    }
    .tags {
        display: inline-block;
        vertical-align: text-bottom;
        width: 24px;
        height: 24px;
        background: url(../assets/ishoney.png) no-repeat;
        background-position: 2px 4px;
        background-size: 22px 22px;
    }
</style>
