<template lang="html">
    <div class="container">
        <g-header @post="report" :hname="this.addParam.username"></g-header>
        <textarea name="content" class="content" placeholder="说点什么吧..." v-model="content">

        </textarea>
        <div class="demo-upload-list" v-for="item in uploadList">
            <template v-if="item.status === 'finished'">
                <img :src="item.url">
                <div class="demo-upload-list-cover">
                    <Icon type="ios-eye-outline" @click.native="handleView(item.name)"></Icon>
                    <Icon type="ios-trash-outline" @click.native="handleRemove(item)"></Icon>
                </div>
            </template>
            <template v-else>
                <Progress v-if="item.showProgress" :percent="item.percentage" hide-info></Progress>
            </template>
        </div>
        <Upload
            ref="upload"
            :show-upload-list="false"
            :default-file-list="defaultList"
            :on-success="handleSuccess"
            :format="['jpg','jpeg','png']"
            :max-size="2048"
            :on-format-error="handleFormatError"
            :on-exceeded-size="handleMaxSize"
            :before-upload="handleBeforeUpload"
            name="image"
            multiple
            type="drag"
            action="http://192.168.253.18:8080/circle/upload_picture"
            :data="param"
            style="float:left;width:58px;">
            <div style="width: 58px;height:58px;line-height: 58px;">
                <Icon type="camera" size="20"></Icon>
            </div>
        </Upload>
        <Modal title="查看图片" v-model="visible">
            <img :src="'https://o5wwk8baw.qnssl.com/' + imgName + '/large'" v-if="visible" style="width: 100%">
        </Modal>
    </div>
</template>

<script>
import Header from '../components/Header.vue'

export default {
    components: {
        GHeader: Header
    },
    created(){
        console.log('wer');
        this.$http.get('http://192.168.253.18:8080/circle/get_id')
            .then((res) => {
                console.log(res);
                this.addParam.id = res.data;
                this.param.id = res.data;
            });
        const reg = /username=.*$/g;
        let username = location.href.match(reg)[0].split('=')[1];
        this.addParam.username = this.param.username =username;
    },
    data () {
        return {
            defaultList: [],
            imgName: '',
            visible: false,
            uploadList: [],
            param: {
                username: '123',
                id: '1'
            },
            addParam: {
                username: '',
                id: '',
                ishoney: '0'
            },
            content: ''
        }
    },
    methods: {
        report (value){
            console.log(value);
            this.addParam.ishoney = value;
            let self = this;
            this.$http.post('http://192.168.253.18:8080/circle/add_friend_circle', {
                    username: this.addParam.username,
                    id: this.addParam.id,
                    content: this.content,
                    ishoney: this.addParam.ishoney
                })
                .then((res) => {
                    console.log(res);
                    self.$router.push('/?username'+this.addParam.username)
                }, (err) => {
                    console.log(err);
                })
        },
        handleView (name) {
            this.imgName = name;
            this.visible = true;
        },
        handleRemove (file) {
            // 从 upload 实例删除数据
            const fileList = this.$refs.upload.fileList;
            this.$refs.upload.fileList.splice(fileList.indexOf(file), 1);
        },
        handleSuccess (res, file) {
            // 因为上传过程为实例，这里模拟添加 url
            file.url = res[1];
            file.name = res[0];
            console.log(res);
            console.log(file);
            console.log(this.defaultList);
        },
        handleFormatError (file) {
            this.$Notice.warning({
                title: '文件格式不正确',
                desc: '文件 ' + file.name + ' 格式不正确，请上传 jpg 或 png 格式的图片。'
            });
        },
        handleMaxSize (file) {
            this.$Notice.warning({
                title: '超出文件大小限制',
                desc: '文件 ' + file.name + ' 太大，不能超过 2M。'
            });
        },
        handleBeforeUpload () {
            this.imgName = (new Date().getTime() + Math.random()).toString();
            console.log(this.name);
            const check = this.uploadList.length < 5;
            if (!check) {
                this.$Notice.warning({
                    title: '最多只能上传 5 张图片。'
                });
            }
            return check;
        }
    },
    mounted () {
        this.uploadList = this.$refs.upload.fileList;
    }
}
</script>

<style scoped>
    .content {
        width: 100%;
        height: 180px;
        padding: 16px;
        box-sizing: border-box;
        background-color: #fff;
        border: none;
        font-size: 16px;
        color: #000;
    }
    .demo-upload-list{
        float: left;
        width: 60px;
        height: 60px;
        text-align: center;
        line-height: 60px;
        border: 1px solid transparent;
        border-radius: 4px;
        overflow: hidden;
        background: #fff;
        position: relative;
        box-shadow: 0 1px 1px rgba(0,0,0,.2);
        margin-right: 4px;
    }
    .demo-upload-list img{
        width: 100%;
        height: 100%;
    }
    .demo-upload-list-cover{
        display: none;
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        background: rgba(0,0,0,.6);
    }
    .demo-upload-list:hover .demo-upload-list-cover{
        display: block;
    }
    .demo-upload-list-cover i{
        color: #fff;
        font-size: 20px;
        cursor: pointer;
        margin: 0 2px;
    }
</style>
