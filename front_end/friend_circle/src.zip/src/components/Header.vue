<template lang="html">
    <div class="header">
        <span class="left" @click="reback()">取消</span>
        <span>动态</span>
        <div class="left">
            <Dropdown trigger="click" style="margin-left: 20px" placement="bottom-end" @on-click="Post">
                <a href="javascript:void(0)" id="postText">
                    发表
                    <Icon type="arrow-down-b"></Icon>
                </a>
                <Dropdown-menu slot="list">
                    <Dropdown-item name="0">仅情侣可见</Dropdown-item>
                    <Dropdown-item name="1">开放</Dropdown-item>
                </Dropdown-menu>
            </Dropdown>
        </div>
    </div>
</template>

<script>
export default {
    name: 'GHeader',
    props: {
        hname: {
            default: 'admin'
        }
    },
    data (){
        return {
            ishoney: 0
        }
    },
    methods: {
        Post (index){
            console.log(index);
            if (index == 0) {
                this.ishoney = 0;
            }
            if (index == 1) {
                this.ishoney = 1;
            }
            this.$emit('post', this.ishoney);
            console.log('被触发');
        },
        reback (){
            this.$router.push('/?username'+this.hname);
            console.log('返回了');
        }
    }
}
</script>

<style scoped>
    .header {
        height: 48px;
        width: 100%;
        background-color: #12b7f5;
        box-sizing: border-box;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding-left: 16px;
        padding-right: 16px;
    }
    .header span {
        display: block;
        color: #fff;
        font-size: 16px;
        font-weight: 500;
    }
</style>
<style>
    #postText {
        color: #fff;
        font-size: 16px;
    }
</style>
