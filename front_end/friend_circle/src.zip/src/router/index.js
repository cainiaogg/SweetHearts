import Vue from 'vue'
import Router from 'vue-router'
import friendCircle from '@/views/friendCircle'
import Add from '@/views/Add'

Vue.use(Router)

export default new Router({
  routes: [
    {
        path: '/',
        name: 'friendCircle',
        component: friendCircle
    },
    {
        path: '/add',
        name: 'Add',
        component: Add
    }
  ]
})
