// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import Iview from 'iview'
import { Loadmore, InfiniteScroll } from 'mint-ui'
import App from './App'
import router from './router'
import VueResource from 'vue-resource'
import 'reset.css'
import 'iview/dist/styles/iview.css'

Vue.use(Iview)
Vue.use(VueResource)
Vue.component(Loadmore.name, Loadmore)
Vue.use(InfiniteScroll)

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  template: '<App/>',
  components: { App }
})
